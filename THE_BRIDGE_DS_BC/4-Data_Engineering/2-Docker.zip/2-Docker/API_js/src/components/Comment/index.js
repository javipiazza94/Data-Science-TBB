export { default } from "./Comment";
