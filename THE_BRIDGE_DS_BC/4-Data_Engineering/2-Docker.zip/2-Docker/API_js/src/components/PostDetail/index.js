export { default } from "./PostDetail";
